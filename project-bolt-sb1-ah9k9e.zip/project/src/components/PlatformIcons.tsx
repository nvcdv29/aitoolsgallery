import React from 'react';
import { 
  Monitor, 
  Smartphone, 
  MessageSquare, 
  Apple, 
  Chrome,
  Globe
} from 'lucide-react';

interface PlatformIconsProps {
  platforms: string[];
  className?: string;
}

export function PlatformIcons({ platforms, className = "h-4 w-4" }: PlatformIconsProps) {
  const getPlatformIcon = (platform: string) => {
    switch (platform.toLowerCase()) {
      case 'web':
        return <Globe className={className} title="Web" />;
      case 'desktop':
        return <Monitor className={className} title="Desktop" />;
      case 'ios':
        return <Apple className={className} title="iOS" />;
      case 'android':
        return <Smartphone className={className} title="Android" />;
      case 'discord':
        return <MessageSquare className={className} title="Discord" />;
      case 'chrome':
        return <Chrome className={className} title="Chrome" />;
      default:
        return null;
    }
  };

  return (
    <div className="flex gap-2">
      {platforms.map((platform, index) => (
        <div key={index} className="text-gray-600">
          {getPlatformIcon(platform)}
        </div>
      ))}
    </div>
  );
}