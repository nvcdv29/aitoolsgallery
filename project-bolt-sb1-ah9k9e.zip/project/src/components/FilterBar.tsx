import React from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { FilterSection } from './FilterSection';

interface FilterBarProps {
  categories: string[];
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  pricingTypes: string[];
  selectedPricing: string;
  onPricingChange: (pricing: string) => void;
  platforms: string[];
  selectedPlatforms: string[];
  onPlatformsChange: (platform: string) => void;
}

export function FilterBar({
  categories,
  selectedCategory,
  onCategoryChange,
  pricingTypes,
  selectedPricing,
  onPricingChange,
  platforms,
  selectedPlatforms,
  onPlatformsChange,
}: FilterBarProps) {
  const scrollContainer = React.useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainer.current) {
      const scrollAmount = 200;
      scrollContainer.current.scrollLeft += direction === 'left' ? -scrollAmount : scrollAmount;
    }
  };

  return (
    <div className="relative">
      <div className="absolute left-0 top-1/2 -translate-y-1/2 z-10">
        <button
          onClick={() => scroll('left')}
          className="p-1 rounded-full bg-white shadow-md hover:bg-gray-50"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
      </div>
      
      <div className="absolute right-0 top-1/2 -translate-y-1/2 z-10">
        <button
          onClick={() => scroll('right')}
          className="p-1 rounded-full bg-white shadow-md hover:bg-gray-50"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div
        ref={scrollContainer}
        className="overflow-x-auto scrollbar-hide space-y-4 px-8"
        style={{
          maskImage: 'linear-gradient(to right, transparent, black 8%, black 92%, transparent 100%)',
          WebkitMaskImage: 'linear-gradient(to right, transparent, black 8%, black 92%, transparent 100%)'
        }}
      >
        <FilterSection
          title="Categories"
          options={categories}
          selected={selectedCategory ? [selectedCategory] : []}
          onChange={(value) => onCategoryChange(value === selectedCategory ? '' : value)}
          multiSelect={false}
        />
        
        <FilterSection
          title="Pricing"
          options={pricingTypes}
          selected={selectedPricing ? [selectedPricing] : []}
          onChange={(value) => onPricingChange(value === selectedPricing ? '' : value)}
          multiSelect={false}
        />
        
        <FilterSection
          title="Platforms"
          options={platforms}
          selected={selectedPlatforms}
          onChange={onPlatformsChange}
          multiSelect={true}
        />
      </div>
    </div>
  );
}