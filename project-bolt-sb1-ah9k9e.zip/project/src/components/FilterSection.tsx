import React from 'react';

interface FilterSectionProps {
  title: string;
  options: string[];
  selected: string[];
  onChange: (value: string) => void;
  multiSelect: boolean;
}

export function FilterSection({
  title,
  options,
  selected,
  onChange,
  multiSelect,
}: FilterSectionProps) {
  return (
    <div className="flex-none">
      <h3 className="text-sm font-medium text-gray-700 mb-2">{title}</h3>
      <div className="flex gap-2">
        {options.map((option) => (
          <button
            key={option}
            onClick={() => onChange(option)}
            className={`
              px-3 py-1.5 rounded-full text-sm font-medium transition-colors
              ${selected.includes(option)
                ? 'bg-blue-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}
            `}
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
}