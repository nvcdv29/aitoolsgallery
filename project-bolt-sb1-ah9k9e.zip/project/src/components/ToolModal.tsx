import React from 'react';
import { X, ExternalLink, Link2, Copy, Check } from 'lucide-react';
import { PlatformIcons } from './PlatformIcons';
import { PricingTiers } from './PricingTiers';
import type { AITool } from '../data/tools';

interface ToolModalProps {
  tool: AITool;
  onClose: () => void;
}

export function ToolModal({ tool, onClose }: ToolModalProps) {
  const [copied, setCopied] = React.useState(false);
  
  const copyLink = () => {
    const url = new URL(window.location.href);
    url.searchParams.set('tool', tool.id);
    navigator.clipboard.writeText(url.toString());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex justify-between items-center">
          <h2 className="text-2xl font-semibold text-gray-900">{tool.name}</h2>
          <div className="flex items-center gap-2">
            <button
              onClick={copyLink}
              className="p-2 hover:bg-gray-100 rounded-full relative group"
              title="Copy link"
            >
              {copied ? (
                <Check className="h-5 w-5 text-green-500" />
              ) : (
                <Link2 className="h-5 w-5" />
              )}
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>
        
        <div className="p-6">
          <img
            src={tool.imageUrl}
            alt={tool.name}
            className="w-full h-64 object-cover rounded-lg mb-6"
          />
          
          <p className="text-gray-600 mb-6">{tool.description}</p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">Features</h3>
              <ul className="list-disc list-inside space-y-1">
                {tool.features.map((feature) => (
                  <li key={feature} className="text-gray-600">{feature}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Details</h3>
              <dl className="space-y-3">
                <div>
                  <dt className="text-gray-500">Category</dt>
                  <dd className="font-medium">{tool.category}</dd>
                </div>
                <div>
                  <dt className="text-gray-500">Available Platforms</dt>
                  <dd className="flex gap-3 mt-1">
                    <PlatformIcons platforms={tool.platforms} className="h-5 w-5" />
                  </dd>
                </div>
                <div>
                  <dt className="text-gray-500">Company</dt>
                  <dd className="font-medium">
                    <a
                      href={tool.company.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
                    >
                      {tool.company.name}
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </dd>
                </div>
              </dl>
            </div>
          </div>

          <h3 className="text-lg font-semibold mb-4">Pricing</h3>
          <PricingTiers tiers={tool.pricingTiers} />
          
          <div className="mt-8">
            <h3 className="text-lg font-semibold mb-4">Download & Access</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {tool.platformLinks.map((link) => (
                <a
                  key={link.platform}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-lg transition-colors"
                >
                  <PlatformIcons platforms={[link.platform]} />
                  <span>{link.platform}</span>
                  <ExternalLink className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}