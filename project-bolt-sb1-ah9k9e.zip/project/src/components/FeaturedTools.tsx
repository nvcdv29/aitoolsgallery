import React from 'react';
import { ExternalLink } from 'lucide-react';
import type { AITool } from '../data/tools';

interface FeaturedToolsProps {
  tools: AITool[];
  onToolClick: (id: string) => void;
}

export function FeaturedTools({ tools, onToolClick }: FeaturedToolsProps) {
  const featuredTools = tools.filter(tool => tool.featured);

  if (featuredTools.length === 0) return null;

  return (
    <div className="mb-8">
      <h2 className="text-xl font-semibold text-gray-900 mb-4">Featured Tools</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {featuredTools.map((tool) => (
          <div
            key={tool.id}
            className="bg-white rounded-lg shadow-sm p-4 flex flex-col"
          >
            <div className="flex items-center gap-4 mb-3">
              <div className="w-12 h-12 flex-shrink-0">
                <img
                  src={tool.logoUrl}
                  alt={`${tool.name} logo`}
                  className="w-full h-full object-contain"
                />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900">{tool.name}</h3>
                <p className="text-sm text-gray-500">{tool.shortDescription}</p>
              </div>
            </div>
            <div className="flex justify-between items-center mt-auto">
              <button
                onClick={() => onToolClick(tool.id)}
                className="text-blue-600 hover:text-blue-800 text-sm font-medium"
              >
                Learn More
              </button>
              <a
                href={tool.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sm px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Visit Site
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}